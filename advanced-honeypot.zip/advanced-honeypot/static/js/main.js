// Filhaal simple, future me yahan pe extra tracking / UI code daal sakte ho
console.log("Honeypot loaded");
